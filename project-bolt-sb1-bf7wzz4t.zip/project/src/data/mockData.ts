import { Customer, ChurnStats, FeatureImportance, ChurnBySegment, TimeSeriesData } from '../types';

// Generate random customers
export const generateCustomers = (count: number): Customer[] => {
  const customers: Customer[] = [];
  const subscriptions: ('Basic' | 'Premium' | 'Enterprise')[] = ['Basic', 'Premium', 'Enterprise'];
  const segments: ('Low Risk' | 'Medium Risk' | 'High Risk')[] = ['Low Risk', 'Medium Risk', 'High Risk'];
  
  for (let i = 0; i < count; i++) {
    const churnProbability = Math.random();
    let segment: 'Low Risk' | 'Medium Risk' | 'High Risk';
    
    if (churnProbability < 0.3) {
      segment = 'Low Risk';
    } else if (churnProbability < 0.7) {
      segment = 'Medium Risk';
    } else {
      segment = 'High Risk';
    }
    
    const joinDate = new Date();
    joinDate.setDate(joinDate.getDate() - Math.floor(Math.random() * 365 * 2));
    
    const lastActive = new Date();
    lastActive.setDate(lastActive.getDate() - Math.floor(Math.random() * 30));
    
    customers.push({
      id: `CUST-${1000 + i}`,
      name: `Customer ${i + 1}`,
      email: `customer${i + 1}@example.com`,
      joinDate: joinDate.toISOString().split('T')[0],
      lastActive: lastActive.toISOString().split('T')[0],
      subscription: subscriptions[Math.floor(Math.random() * subscriptions.length)],
      monthlySpend: Math.floor(Math.random() * 1000) + 50,
      churnProbability,
      segment,
      engagementScore: Math.floor(Math.random() * 100),
      supportTickets: Math.floor(Math.random() * 10),
      productUsage: Math.floor(Math.random() * 100),
    });
  }
  
  return customers;
};

export const mockCustomers = generateCustomers(100);

export const churnStats: ChurnStats = {
  totalCustomers: mockCustomers.length,
  churnRate: 0.15,
  atRiskCount: mockCustomers.filter(c => c.segment === 'High Risk').length,
  retentionRate: 0.85,
  averageLifetime: 18, // months
};

export const featureImportance: FeatureImportance[] = [
  { 
    feature: 'Product Usage', 
    importance: 0.32, 
    description: 'Frequency and depth of product engagement'
  },
  { 
    feature: 'Support Tickets', 
    importance: 0.28, 
    description: 'Number and frequency of customer support interactions'
  },
  { 
    feature: 'Subscription Type', 
    importance: 0.18, 
    description: 'Current subscription plan level'
  },
  { 
    feature: 'Monthly Spend', 
    importance: 0.12, 
    description: 'Average monthly revenue from customer'
  },
  { 
    feature: 'Account Age', 
    importance: 0.10, 
    description: 'Time since customer first signed up'
  },
];

export const churnBySegment: ChurnBySegment[] = [
  { segment: 'Enterprise', churnRate: 0.08, customerCount: mockCustomers.filter(c => c.subscription === 'Enterprise').length },
  { segment: 'Premium', churnRate: 0.12, customerCount: mockCustomers.filter(c => c.subscription === 'Premium').length },
  { segment: 'Basic', churnRate: 0.22, customerCount: mockCustomers.filter(c => c.subscription === 'Basic').length },
];

export const timeSeriesData: TimeSeriesData[] = (() => {
  const data: TimeSeriesData[] = [];
  const today = new Date();
  
  for (let i = 0; i < 12; i++) {
    const date = new Date();
    date.setMonth(today.getMonth() - 11 + i);
    
    data.push({
      date: `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}`,
      churnRate: 0.1 + Math.random() * 0.1,
      newCustomers: Math.floor(Math.random() * 50) + 20,
    });
  }
  
  return data;
})();