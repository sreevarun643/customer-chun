import React from 'react';
import { FeatureImportance } from '../../types';

interface FeatureImportanceChartProps {
  data: FeatureImportance[];
  className?: string;
}

const FeatureImportanceChart: React.FC<FeatureImportanceChartProps> = ({ 
  data,
  className = '',
}) => {
  // Sort data by importance (descending)
  const sortedData = [...data].sort((a, b) => b.importance - a.importance);
  
  return (
    <div className={`space-y-4 ${className}`}>
      {sortedData.map((feature) => (
        <div key={feature.feature} className="space-y-1">
          <div className="flex justify-between text-sm">
            <div className="font-medium">{feature.feature}</div>
            <div className="text-gray-500">{(feature.importance * 100).toFixed(1)}%</div>
          </div>
          <div className="w-full bg-gray-200 rounded-full h-2.5">
            <div 
              className="bg-blue-600 h-2.5 rounded-full transition-all duration-500 ease-out"
              style={{ width: `${feature.importance * 100}%` }}
            ></div>
          </div>
          <div className="text-xs text-gray-500">{feature.description}</div>
        </div>
      ))}
    </div>
  );
};

export default FeatureImportanceChart;