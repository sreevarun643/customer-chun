import React from 'react';

interface DataPoint {
  label: string;
  value: number;
}

interface LineChartProps {
  data: DataPoint[];
  height?: number;
  lineColor?: string;
  fillColor?: string;
  className?: string;
  valueFormatter?: (value: number) => string;
}

const LineChart: React.FC<LineChartProps> = ({
  data,
  height = 240,
  lineColor = '#3B82F6',
  fillColor = 'rgba(59, 130, 246, 0.1)',
  className = '',
  valueFormatter = (value) => value.toFixed(2),
}) => {
  if (data.length < 2) return <div>Not enough data</div>;

  const values = data.map(d => d.value);
  const minValue = Math.min(...values);
  const maxValue = Math.max(...values);
  const range = maxValue - minValue;
  
  // Add padding to the range
  const paddedMin = Math.max(0, minValue - range * 0.1);
  const paddedMax = maxValue + range * 0.1;
  const paddedRange = paddedMax - paddedMin;

  const getY = (value: number) => {
    const percent = paddedRange !== 0 ? (paddedMax - value) / paddedRange : 0.5;
    return percent * height;
  };

  const stepX = 100 / (data.length - 1);
  
  // Generate the path for the line
  let path = `M 0,${getY(data[0].value)}`;
  data.forEach((point, index) => {
    if (index > 0) {
      const x = index * stepX;
      path += ` L ${x},${getY(point.value)}`;
    }
  });

  // Generate the path for the area under the line
  let areaPath = `M 0,${getY(data[0].value)}`;
  data.forEach((point, index) => {
    if (index > 0) {
      const x = index * stepX;
      areaPath += ` L ${x},${getY(point.value)}`;
    }
  });
  areaPath += ` L ${100},${height} L 0,${height} Z`;

  return (
    <div className={`w-full ${className}`} style={{ height: `${height}px` }}>
      <svg width="100%" height={height} viewBox={`0 0 100 ${height}`} preserveAspectRatio="none">
        <path
          d={areaPath}
          fill={fillColor}
          opacity="0.8"
        />
        <path
          d={path}
          fill="none"
          stroke={lineColor}
          strokeWidth="2"
          strokeLinecap="round"
          strokeLinejoin="round"
        />
        {data.map((point, index) => (
          <g key={index}>
            <circle
              cx={index * stepX}
              cy={getY(point.value)}
              r="3"
              fill="white"
              stroke={lineColor}
              strokeWidth="1.5"
              className="transition-all duration-300 hover:r-4"
            />
            <circle
              cx={index * stepX}
              cy={getY(point.value)}
              r="12"
              fill="transparent"
              className="cursor-pointer"
              onMouseOver={(e) => {
                const tooltip = document.getElementById('tooltip');
                if (tooltip) {
                  tooltip.style.display = 'block';
                  tooltip.style.left = `${e.clientX + 10}px`;
                  tooltip.style.top = `${e.clientY + 10}px`;
                  tooltip.textContent = `${point.label}: ${valueFormatter(point.value)}`;
                }
              }}
              onMouseOut={() => {
                const tooltip = document.getElementById('tooltip');
                if (tooltip) {
                  tooltip.style.display = 'none';
                }
              }}
            />
          </g>
        ))}
      </svg>
      <div
        id="tooltip"
        className="absolute hidden bg-gray-800 text-white px-2 py-1 rounded text-xs pointer-events-none z-10"
      ></div>
      
      <div className="flex justify-between mt-2">
        {data.map((point, index) => (
          <div key={index} className="text-xs text-gray-500 text-center" style={{ width: `${stepX}%` }}>
            {point.label}
          </div>
        ))}
      </div>
    </div>
  );
};

export default LineChart;