import React from 'react';

interface BarChartProps {
  data: {
    label: string;
    value: number;
    color?: string;
  }[];
  height?: number;
  className?: string;
  valueFormatter?: (value: number) => string;
}

const BarChart: React.FC<BarChartProps> = ({
  data,
  height = 240,
  className = '',
  valueFormatter = (value) => value.toFixed(2),
}) => {
  const maxValue = Math.max(...data.map(item => item.value));
  const colors = ['#3B82F6', '#8B5CF6', '#EC4899', '#F59E0B', '#10B981'];

  return (
    <div className={`w-full ${className}`} style={{ height: `${height}px` }}>
      <div className="flex items-end justify-between h-full">
        {data.map((item, index) => {
          const heightPercent = (item.value / maxValue) * 100;
          const barColor = item.color || colors[index % colors.length];
          
          return (
            <div 
              key={item.label} 
              className="flex flex-col items-center justify-end flex-1 mx-1" 
            >
              <div className="flex flex-col items-center w-full">
                <div 
                  className="text-xs font-medium text-gray-700 mb-1"
                  title={valueFormatter(item.value)}
                >
                  {valueFormatter(item.value)}
                </div>
                <div 
                  className="w-full rounded-t transition-all duration-500 ease-in-out"
                  style={{ 
                    height: `${heightPercent}%`, 
                    backgroundColor: barColor,
                    minHeight: '4px',
                  }}
                />
                <div className="w-full text-xs font-medium text-gray-500 mt-2 text-center truncate">
                  {item.label}
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};

export default BarChart;