import React, { useState } from 'react';
import { Customer } from '../../types';
import Badge from '../ui/Badge';
import { ChevronDown, ChevronUp, ArrowUpDown } from 'lucide-react';

interface CustomerTableProps {
  customers: Customer[];
  onViewDetails: (customerId: string) => void;
}

type SortField = keyof Customer;
type SortDirection = 'asc' | 'desc';

const CustomerTable: React.FC<CustomerTableProps> = ({ customers, onViewDetails }) => {
  const [sortField, setSortField] = useState<SortField>('churnProbability');
  const [sortDirection, setSortDirection] = useState<SortDirection>('desc');
  const [expandedCustomer, setExpandedCustomer] = useState<string | null>(null);

  const handleSort = (field: SortField) => {
    if (sortField === field) {
      setSortDirection(sortDirection === 'asc' ? 'desc' : 'asc');
    } else {
      setSortField(field);
      setSortDirection('desc');
    }
  };

  const sortedCustomers = [...customers].sort((a, b) => {
    const aValue = a[sortField];
    const bValue = b[sortField];
    
    if (typeof aValue === 'number' && typeof bValue === 'number') {
      return sortDirection === 'asc' ? aValue - bValue : bValue - aValue;
    }
    
    const aString = String(aValue);
    const bString = String(bValue);
    
    return sortDirection === 'asc' 
      ? aString.localeCompare(bString) 
      : bString.localeCompare(aString);
  });

  const toggleExpand = (customerId: string) => {
    setExpandedCustomer(expandedCustomer === customerId ? null : customerId);
  };

  const getChurnRiskBadge = (probability: number) => {
    if (probability < 0.3) {
      return <Badge variant="success">Low Risk</Badge>;
    } else if (probability < 0.7) {
      return <Badge variant="warning">Medium Risk</Badge>;
    } else {
      return <Badge variant="danger">High Risk</Badge>;
    }
  };

  const renderSortIcon = (field: SortField) => {
    if (sortField !== field) {
      return <ArrowUpDown className="h-4 w-4 ml-1" />;
    }
    
    return sortDirection === 'asc' 
      ? <ChevronUp className="h-4 w-4 ml-1" /> 
      : <ChevronDown className="h-4 w-4 ml-1" />;
  };

  return (
    <div className="overflow-x-auto">
      <table className="min-w-full divide-y divide-gray-200">
        <thead className="bg-gray-50">
          <tr>
            <th 
              scope="col" 
              className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
            >
              <button
                className="flex items-center font-medium focus:outline-none"
                onClick={() => handleSort('name')}
              >
                Customer {renderSortIcon('name')}
              </button>
            </th>
            <th 
              scope="col" 
              className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
            >
              <button
                className="flex items-center font-medium focus:outline-none"
                onClick={() => handleSort('subscription')}
              >
                Subscription {renderSortIcon('subscription')}
              </button>
            </th>
            <th 
              scope="col" 
              className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
            >
              <button
                className="flex items-center font-medium focus:outline-none"
                onClick={() => handleSort('monthlySpend')}
              >
                Monthly Spend {renderSortIcon('monthlySpend')}
              </button>
            </th>
            <th 
              scope="col" 
              className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
            >
              <button
                className="flex items-center font-medium focus:outline-none"
                onClick={() => handleSort('churnProbability')}
              >
                Churn Risk {renderSortIcon('churnProbability')}
              </button>
            </th>
            <th 
              scope="col" 
              className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider"
            >
              Actions
            </th>
          </tr>
        </thead>
        <tbody className="bg-white divide-y divide-gray-200">
          {sortedCustomers.map((customer) => (
            <React.Fragment key={customer.id}>
              <tr 
                className={`hover:bg-gray-50 transition-colors cursor-pointer ${expandedCustomer === customer.id ? 'bg-blue-50' : ''}`}
                onClick={() => toggleExpand(customer.id)}
              >
                <td className="px-6 py-4 whitespace-nowrap">
                  <div className="flex items-center">
                    <div className="text-sm font-medium text-gray-900">{customer.name}</div>
                  </div>
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <div className="text-sm text-gray-900">{customer.subscription}</div>
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <div className="text-sm text-gray-900">${customer.monthlySpend}</div>
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <div>
                    {getChurnRiskBadge(customer.churnProbability)}
                    <span className="ml-2 text-sm text-gray-500">
                      {(customer.churnProbability * 100).toFixed(0)}%
                    </span>
                  </div>
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      onViewDetails(customer.id);
                    }}
                    className="text-blue-600 hover:text-blue-900 focus:outline-none"
                  >
                    View Details
                  </button>
                </td>
              </tr>
              {expandedCustomer === customer.id && (
                <tr className="bg-blue-50">
                  <td colSpan={5} className="px-6 py-4">
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm">
                      <div>
                        <p className="text-gray-500">Customer Since</p>
                        <p className="font-medium">{customer.joinDate}</p>
                      </div>
                      <div>
                        <p className="text-gray-500">Last Active</p>
                        <p className="font-medium">{customer.lastActive}</p>
                      </div>
                      <div>
                        <p className="text-gray-500">Email</p>
                        <p className="font-medium">{customer.email}</p>
                      </div>
                      <div>
                        <p className="text-gray-500">Engagement Score</p>
                        <p className="font-medium">{customer.engagementScore}%</p>
                      </div>
                      <div>
                        <p className="text-gray-500">Support Tickets</p>
                        <p className="font-medium">{customer.supportTickets}</p>
                      </div>
                      <div>
                        <p className="text-gray-500">Product Usage</p>
                        <p className="font-medium">{customer.productUsage}%</p>
                      </div>
                    </div>
                  </td>
                </tr>
              )}
            </React.Fragment>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default CustomerTable;