import React from 'react';
import { Customer } from '../../types';
import Card from '../ui/Card';
import Badge from '../ui/Badge';
import { ArrowLeft } from 'lucide-react';

interface CustomerDetailProps {
  customer: Customer;
  onBack: () => void;
}

const CustomerDetail: React.FC<CustomerDetailProps> = ({ customer, onBack }) => {
  const getChurnRiskColor = (probability: number) => {
    if (probability < 0.3) return 'bg-green-500';
    if (probability < 0.7) return 'bg-yellow-500';
    return 'bg-red-500';
  };

  const getRiskFactor = (value: number, type: 'high' | 'low'): boolean => {
    if (type === 'high') {
      return value > 0.6;
    }
    return value < 0.4;
  };

  const customerAge = (() => {
    const joinDate = new Date(customer.joinDate);
    const now = new Date();
    const diffTime = Math.abs(now.getTime() - joinDate.getTime());
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    return diffDays;
  })();

  return (
    <div className="space-y-6">
      <div className="flex items-center">
        <button
          onClick={onBack}
          className="mr-4 p-2 rounded-full hover:bg-gray-100 transition-colors"
        >
          <ArrowLeft className="h-5 w-5" />
        </button>
        <h2 className="text-2xl font-bold">{customer.name}</h2>
        <div className="ml-4">
          {customer.churnProbability < 0.3 && <Badge variant="success">Low Risk</Badge>}
          {customer.churnProbability >= 0.3 && customer.churnProbability < 0.7 && <Badge variant="warning">Medium Risk</Badge>}
          {customer.churnProbability >= 0.7 && <Badge variant="danger">High Risk</Badge>}
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card className="col-span-1 md:col-span-2">
          <h3 className="text-lg font-medium mb-4">Customer Information</h3>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <p className="text-sm text-gray-500">Customer ID</p>
              <p className="font-medium">{customer.id}</p>
            </div>
            <div>
              <p className="text-sm text-gray-500">Email</p>
              <p className="font-medium">{customer.email}</p>
            </div>
            <div>
              <p className="text-sm text-gray-500">Join Date</p>
              <p className="font-medium">{customer.joinDate}</p>
            </div>
            <div>
              <p className="text-sm text-gray-500">Customer Age</p>
              <p className="font-medium">{customerAge} days</p>
            </div>
            <div>
              <p className="text-sm text-gray-500">Last Active</p>
              <p className="font-medium">{customer.lastActive}</p>
            </div>
            <div>
              <p className="text-sm text-gray-500">Subscription</p>
              <p className="font-medium">{customer.subscription}</p>
            </div>
            <div>
              <p className="text-sm text-gray-500">Monthly Spend</p>
              <p className="font-medium">${customer.monthlySpend}</p>
            </div>
            <div>
              <p className="text-sm text-gray-500">Engagement Score</p>
              <p className="font-medium">{customer.engagementScore}%</p>
            </div>
          </div>
        </Card>

        <Card>
          <h3 className="text-lg font-medium mb-4">Churn Risk</h3>
          <div className="flex flex-col items-center justify-center space-y-4">
            <div 
              className="relative h-40 w-40 rounded-full flex items-center justify-center"
              style={{ 
                background: `conic-gradient(${getChurnRiskColor(customer.churnProbability)} ${customer.churnProbability * 360}deg, #e5e7eb 0)` 
              }}
            >
              <div className="h-32 w-32 rounded-full bg-white flex items-center justify-center">
                <span className="text-3xl font-bold">
                  {(customer.churnProbability * 100).toFixed(0)}%
                </span>
              </div>
            </div>
            <p className="text-sm text-center text-gray-500">
              {customer.churnProbability < 0.3 && 'This customer has a low risk of churning.'}
              {customer.churnProbability >= 0.3 && customer.churnProbability < 0.7 && 'This customer has a moderate risk of churning.'}
              {customer.churnProbability >= 0.7 && 'This customer has a high risk of churning.'}
            </p>
          </div>
        </Card>
      </div>

      <Card>
        <h3 className="text-lg font-medium mb-4">Risk Factors and Recommendations</h3>
        <div className="space-y-4">
          <div className="border-l-4 border-blue-500 pl-4">
            <h4 className="font-medium">Customer Insights</h4>
            <p className="text-sm text-gray-500">
              {customer.name} has been a customer for {customerAge} days with a {customer.subscription} subscription.
              {customer.churnProbability >= 0.5 
                ? ` Our model indicates an elevated churn risk of ${(customer.churnProbability * 100).toFixed(0)}%.` 
                : ` Our model indicates a stable customer with a churn risk of only ${(customer.churnProbability * 100).toFixed(0)}%.`}
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="border-l-4 border-yellow-500 pl-4">
              <h4 className="font-medium">Risk Factors</h4>
              <ul className="text-sm text-gray-500 list-disc list-inside">
                {getRiskFactor(customer.engagementScore / 100, 'low') && (
                  <li>Low engagement score ({customer.engagementScore}%)</li>
                )}
                {customer.supportTickets > 5 && (
                  <li>High number of support tickets ({customer.supportTickets})</li>
                )}
                {getRiskFactor(customer.productUsage / 100, 'low') && (
                  <li>Low product usage ({customer.productUsage}%)</li>
                )}
                {customerAge < 90 && (
                  <li>New customer (less than 90 days)</li>
                )}
              </ul>
            </div>

            <div className="border-l-4 border-green-500 pl-4">
              <h4 className="font-medium">Recommendations</h4>
              <ul className="text-sm text-gray-500 list-disc list-inside">
                {getRiskFactor(customer.engagementScore / 100, 'low') && (
                  <li>Schedule a product training session</li>
                )}
                {customer.supportTickets > 5 && (
                  <li>Assign dedicated support representative</li>
                )}
                {getRiskFactor(customer.productUsage / 100, 'low') && (
                  <li>Send feature highlight email campaign</li>
                )}
                {customer.subscription === 'Basic' && (
                  <li>Offer Premium trial with premium features</li>
                )}
                {customerAge < 90 && (
                  <li>Send onboarding completion check-in</li>
                )}
              </ul>
            </div>
          </div>
        </div>
      </Card>
    </div>
  );
};

export default CustomerDetail;