export interface Customer {
  id: string;
  name: string;
  email: string;
  joinDate: string;
  lastActive: string;
  subscription: 'Basic' | 'Premium' | 'Enterprise';
  monthlySpend: number;
  churnProbability: number;
  segment: 'Low Risk' | 'Medium Risk' | 'High Risk';
  engagementScore: number;
  supportTickets: number;
  productUsage: number;
}

export interface ChurnStats {
  totalCustomers: number;
  churnRate: number;
  atRiskCount: number;
  retentionRate: number;
  averageLifetime: number;
}

export interface FeatureImportance {
  feature: string;
  importance: number;
  description: string;
}

export interface ChurnBySegment {
  segment: string;
  churnRate: number;
  customerCount: number;
}

export interface TimeSeriesData {
  date: string;
  churnRate: number;
  newCustomers: number;
}