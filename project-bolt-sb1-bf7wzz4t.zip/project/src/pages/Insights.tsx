import React from 'react';
import Card from '../components/ui/Card';
import { featureImportance, timeSeriesData, churnBySegment } from '../data/mockData';
import FeatureImportanceChart from '../components/charts/FeatureImportanceChart';
import LineChart from '../components/charts/LineChart';
import BarChart from '../components/charts/BarChart';

const Insights: React.FC = () => {
  const churnTimeData = timeSeriesData.map(item => ({
    label: item.date,
    value: item.churnRate
  }));

  const newCustomersData = timeSeriesData.map(item => ({
    label: item.date,
    value: item.newCustomers
  }));

  const segmentData = churnBySegment.map(item => ({
    label: item.segment,
    value: item.churnRate,
  }));

  const segmentCountData = churnBySegment.map(item => ({
    label: item.segment,
    value: item.customerCount,
  }));

  return (
    <div className="space-y-6">
      <h2 className="text-2xl font-bold">Insights</h2>
      
      <Card>
        <h3 className="text-lg font-medium mb-4">Churn Analysis Summary</h3>
        <p className="text-gray-700 mb-4">
          Our machine learning model has analyzed customer behavior patterns and identified several key factors
          contributing to customer churn. Product usage and support ticket volume are the strongest predictors,
          accounting for over 60% of the model's predictive power.
        </p>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-6">
          <div>
            <h4 className="font-medium text-gray-800 mb-2">Key Observations</h4>
            <ul className="list-disc list-inside space-y-1 text-gray-600">
              <li>Basic tier subscribers churn at 2.7x the rate of Enterprise customers</li>
              <li>Customers with low engagement scores have a 78% higher churn probability</li>
              <li>First 90 days are critical - 45% of churns occur during this period</li>
              <li>Customers with 3+ support tickets are significantly more likely to churn</li>
            </ul>
          </div>
          <div>
            <h4 className="font-medium text-gray-800 mb-2">Recommendations</h4>
            <ul className="list-disc list-inside space-y-1 text-gray-600">
              <li>Implement targeted onboarding for new customers</li>
              <li>Enhance support experience for customers opening multiple tickets</li>
              <li>Develop feature education program for low-engagement users</li>
              <li>Consider restructuring Basic tier to improve retention</li>
            </ul>
          </div>
        </div>
      </Card>
      
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card title="Churn Drivers">
          <FeatureImportanceChart data={featureImportance} />
        </Card>
        <Card title="Feature Correlation Matrix">
          <div className="p-4 bg-gray-50 rounded-lg h-full flex items-center justify-center">
            <div className="text-center text-gray-500">
              <p className="mb-2">Machine Learning Model Insights</p>
              <p className="text-sm">Our model has identified that low engagement combined with high support ticket volume is the strongest predictor of churn, with 87% accuracy.</p>
            </div>
          </div>
        </Card>
      </div>
      
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card title="Churn Rate Trend">
          <LineChart
            data={churnTimeData}
            height={240}
            valueFormatter={(value) => `${(value * 100).toFixed(1)}%`}
          />
          <div className="mt-4 text-sm text-gray-500">
            <p>Churn rates have increased slightly in the past quarter, with seasonal patterns visible at year-end.</p>
          </div>
        </Card>
        <Card title="New Customer Acquisition">
          <LineChart
            data={newCustomersData}
            height={240}
            lineColor="#10B981"
            fillColor="rgba(16, 185, 129, 0.1)"
          />
          <div className="mt-4 text-sm text-gray-500">
            <p>New customer acquisition increased by 15% in the last quarter but shows volatility.</p>
          </div>
        </Card>
      </div>
      
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card title="Churn Rate by Segment">
          <BarChart
            data={segmentData}
            height={240}
            valueFormatter={(value) => `${(value * 100).toFixed(1)}%`}
          />
          <div className="mt-4 text-sm text-gray-500">
            <p>Basic tier shows significantly higher churn compared to Premium and Enterprise segments.</p>
          </div>
        </Card>
        <Card title="Customer Distribution by Segment">
          <BarChart
            data={segmentCountData}
            height={240}
          />
          <div className="mt-4 text-sm text-gray-500">
            <p>Most customers are in the Premium segment, with Basic and Enterprise more evenly distributed.</p>
          </div>
        </Card>
      </div>
    </div>
  );
};

export default Insights;