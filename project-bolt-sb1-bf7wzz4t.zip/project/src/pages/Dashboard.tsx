import React from 'react';
import Card from '../components/ui/Card';
import StatCard from '../components/ui/StatCard';
import LineChart from '../components/charts/LineChart';
import BarChart from '../components/charts/BarChart';
import FeatureImportanceChart from '../components/charts/FeatureImportanceChart';
import { churnStats, featureImportance, churnBySegment, timeSeriesData } from '../data/mockData';
import { Activity, Users, AlertTriangle, TrendingDown, Clock } from 'lucide-react';

const Dashboard: React.FC = () => {
  const churnTimeData = timeSeriesData.map(item => ({
    label: item.date,
    value: item.churnRate
  }));

  const segmentData = churnBySegment.map(item => ({
    label: item.segment,
    value: item.churnRate,
  }));

  return (
    <div className="space-y-6">
      <h2 className="text-2xl font-bold">Dashboard</h2>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <StatCard
          title="Total Customers"
          value={churnStats.totalCustomers}
          icon={<Users className="h-6 w-6" />}
          description="Active customer base"
        />
        <StatCard
          title="Churn Rate"
          value={`${(churnStats.churnRate * 100).toFixed(1)}%`}
          icon={<TrendingDown className="h-6 w-6" />}
          trend={{ value: -2.5, isPositive: true }}
        />
        <StatCard
          title="At Risk Customers"
          value={churnStats.atRiskCount}
          icon={<AlertTriangle className="h-6 w-6" />}
          description="High churn probability"
        />
        <StatCard
          title="Avg. Customer Lifetime"
          value={`${churnStats.averageLifetime} months`}
          icon={<Clock className="h-6 w-6" />}
          trend={{ value: 1.5, isPositive: true }}
        />
      </div>
      
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <Card title="Churn Rate Trend" className="lg:col-span-2">
          <LineChart
            data={churnTimeData}
            height={240}
            valueFormatter={(value) => `${(value * 100).toFixed(1)}%`}
          />
        </Card>
        <Card title="Churn by Segment">
          <BarChart
            data={segmentData}
            height={240}
            valueFormatter={(value) => `${(value * 100).toFixed(1)}%`}
          />
        </Card>
      </div>
      
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card title="Top Churn Factors">
          <FeatureImportanceChart data={featureImportance} />
        </Card>
        <Card title="Recommended Actions">
          <div className="space-y-4">
            <div className="flex items-start p-4 bg-blue-50 rounded-lg">
              <div className="flex-shrink-0 pt-0.5">
                <Activity className="h-5 w-5 text-blue-600" />
              </div>
              <div className="ml-3">
                <h3 className="text-sm font-medium text-blue-800">Engage inactive users</h3>
                <p className="mt-1 text-sm text-blue-700">
                  Target the 28 users with low engagement scores with a personalized email campaign.
                </p>
              </div>
            </div>
            
            <div className="flex items-start p-4 bg-yellow-50 rounded-lg">
              <div className="flex-shrink-0 pt-0.5">
                <AlertTriangle className="h-5 w-5 text-yellow-600" />
              </div>
              <div className="ml-3">
                <h3 className="text-sm font-medium text-yellow-800">Basic plan at risk</h3>
                <p className="mt-1 text-sm text-yellow-700">
                  Basic plan customers show a 22% churn rate. Consider offering premium features trial.
                </p>
              </div>
            </div>
            
            <div className="flex items-start p-4 bg-green-50 rounded-lg">
              <div className="flex-shrink-0 pt-0.5">
                <Users className="h-5 w-5 text-green-600" />
              </div>
              <div className="ml-3">
                <h3 className="text-sm font-medium text-green-800">Upgrade opportunities</h3>
                <p className="mt-1 text-sm text-green-700">
                  15 Premium customers have usage patterns suggesting they would benefit from Enterprise features.
                </p>
              </div>
            </div>
          </div>
        </Card>
      </div>
    </div>
  );
};

export default Dashboard;