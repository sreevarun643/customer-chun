import React, { useState } from 'react';
import Card from '../components/ui/Card';
import Badge from '../components/ui/Badge';
import { Settings as SettingsIcon, Bell, Moon, Sun, RefreshCw, Save, Lock, BrainCircuit } from 'lucide-react';

const Settings: React.FC = () => {
  const [modelThreshold, setModelThreshold] = useState<number>(0.7);
  const [refreshInterval, setRefreshInterval] = useState<number>(24);
  const [emailNotifications, setEmailNotifications] = useState<boolean>(true);
  const [highRiskAlerts, setHighRiskAlerts] = useState<boolean>(true);
  const [darkMode, setDarkMode] = useState<boolean>(false);
  const [savedSettings, setSavedSettings] = useState<boolean>(false);

  const handleSaveSettings = () => {
    setSavedSettings(true);
    setTimeout(() => setSavedSettings(false), 3000);
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold">Settings</h2>
        <button
          onClick={handleSaveSettings}
          className="flex items-center bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-md transition-colors"
        >
          <Save className="h-4 w-4 mr-2" />
          Save Changes
        </button>
      </div>

      {savedSettings && (
        <div className="bg-green-50 border border-green-200 text-green-800 px-4 py-3 rounded-md flex items-center">
          <RefreshCw className="h-5 w-5 mr-2 animate-spin" />
          Settings saved successfully!
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card className="space-y-6">
          <div className="flex items-center">
            <BrainCircuit className="h-6 w-6 text-blue-600 mr-2" />
            <h3 className="text-lg font-medium">Model Configuration</h3>
          </div>

          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                High Risk Threshold
              </label>
              <div className="flex items-center space-x-4">
                <input
                  type="range"
                  min="0.5"
                  max="0.9"
                  step="0.05"
                  value={modelThreshold}
                  onChange={(e) => setModelThreshold(parseFloat(e.target.value))}
                  className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer"
                />
                <span className="bg-gray-100 px-2 py-1 rounded-md text-sm font-medium w-16 text-center">
                  {(modelThreshold * 100).toFixed(0)}%
                </span>
              </div>
              <p className="text-xs text-gray-500 mt-1">
                Customers with churn probability above this threshold will be flagged as high risk.
              </p>
            </div>

            <div className="pt-4 border-t border-gray-200">
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Model Features
              </label>
              <div className="flex flex-wrap gap-2">
                <Badge variant="info">Product Usage</Badge>
                <Badge variant="info">Support Tickets</Badge>
                <Badge variant="info">Subscription Type</Badge>
                <Badge variant="info">Monthly Spend</Badge>
                <Badge variant="info">Account Age</Badge>
                <Badge variant="default">
                  <button className="focus:outline-none">+ Add Feature</button>
                </Badge>
              </div>
            </div>

            <div className="pt-4 border-t border-gray-200">
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Data Refresh Interval
              </label>
              <div className="relative">
                <select
                  value={refreshInterval}
                  onChange={(e) => setRefreshInterval(parseInt(e.target.value))}
                  className="block w-full pl-3 pr-10 py-2 text-base border-gray-300 focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm rounded-md"
                >
                  <option value="3">Every 3 hours</option>
                  <option value="6">Every 6 hours</option>
                  <option value="12">Every 12 hours</option>
                  <option value="24">Daily</option>
                  <option value="168">Weekly</option>
                </select>
              </div>
            </div>
          </div>
        </Card>

        <Card className="space-y-6">
          <div className="flex items-center">
            <SettingsIcon className="h-6 w-6 text-blue-600 mr-2" />
            <h3 className="text-lg font-medium">Account Preferences</h3>
          </div>

          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-700">Dark Mode</p>
                <p className="text-xs text-gray-500">Switch between light and dark theme</p>
              </div>
              <button
                onClick={() => setDarkMode(!darkMode)}
                className="bg-gray-200 relative inline-flex h-6 w-11 items-center rounded-full"
              >
                <span className="sr-only">Toggle dark mode</span>
                <span
                  className={`${
                    darkMode ? 'translate-x-6 bg-blue-600' : 'translate-x-1 bg-white'
                  } inline-block h-4 w-4 transform rounded-full transition-transform`}
                />
                <span className="absolute left-0 top-0 flex items-center justify-center h-full px-1.5">
                  <Moon className={`h-3 w-3 ${darkMode ? 'text-white' : 'text-gray-400'}`} />
                </span>
                <span className="absolute right-0 top-0 flex items-center justify-center h-full px-1.5">
                  <Sun className={`h-3 w-3 ${!darkMode ? 'text-gray-600' : 'text-gray-400'}`} />
                </span>
              </button>
            </div>

            <div className="pt-4 border-t border-gray-200">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-700">Email Notifications</p>
                  <p className="text-xs text-gray-500">Receive monthly churn reports via email</p>
                </div>
                <div>
                  <label htmlFor="email-toggle" className="flex items-center cursor-pointer">
                    <div className="relative">
                      <input
                        type="checkbox"
                        id="email-toggle"
                        className="sr-only"
                        checked={emailNotifications}
                        onChange={() => setEmailNotifications(!emailNotifications)}
                      />
                      <div className="block bg-gray-200 w-11 h-6 rounded-full"></div>
                      <div
                        className={`dot absolute left-1 top-1 bg-white w-4 h-4 rounded-full transition ${
                          emailNotifications ? 'transform translate-x-5 bg-blue-600' : ''
                        }`}
                      ></div>
                    </div>
                  </label>
                </div>
              </div>
            </div>

            <div className="pt-4 border-t border-gray-200">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-700">High Risk Alerts</p>
                  <p className="text-xs text-gray-500">Get notified when customers become high risk</p>
                </div>
                <div>
                  <label htmlFor="alert-toggle" className="flex items-center cursor-pointer">
                    <div className="relative">
                      <input
                        type="checkbox"
                        id="alert-toggle"
                        className="sr-only"
                        checked={highRiskAlerts}
                        onChange={() => setHighRiskAlerts(!highRiskAlerts)}
                      />
                      <div className="block bg-gray-200 w-11 h-6 rounded-full"></div>
                      <div
                        className={`dot absolute left-1 top-1 bg-white w-4 h-4 rounded-full transition ${
                          highRiskAlerts ? 'transform translate-x-5 bg-blue-600' : ''
                        }`}
                      ></div>
                    </div>
                  </label>
                </div>
              </div>
            </div>
          </div>
        </Card>
      </div>

      <Card>
        <div className="flex items-center mb-6">
          <Lock className="h-6 w-6 text-blue-600 mr-2" />
          <h3 className="text-lg font-medium">API Access</h3>
        </div>

        <div className="space-y-6">
          <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
            <div>
              <p className="text-sm font-medium text-gray-700">API Key</p>
              <p className="text-xs text-gray-500 mt-1">Use this key to access the ChurnPredict API</p>
            </div>
            <div className="flex items-center">
              <div className="bg-gray-100 px-3 py-2 rounded-md text-sm font-mono mr-2">
                ••••••••••••••••
              </div>
              <button className="text-blue-600 hover:text-blue-800 text-sm">
                Reveal
              </button>
            </div>
          </div>

          <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
            <div>
              <p className="text-sm font-medium text-gray-700">Webhook URL</p>
              <p className="text-xs text-gray-500 mt-1">Receive real-time notifications</p>
            </div>
            <div className="flex items-center">
              <input
                type="text"
                placeholder="https://your-app.com/webhook"
                className="border border-gray-300 rounded-md text-sm py-2 px-3 w-64"
              />
            </div>
          </div>

          <div className="flex items-center justify-between">
            <p className="text-sm text-gray-500">
              Learn more about our <a href="#" className="text-blue-600 hover:underline">API documentation</a>
            </p>
            <button className="px-4 py-2 border border-gray-300 rounded-md text-sm font-medium hover:bg-gray-50 transition-colors">
              Regenerate API Key
            </button>
          </div>
        </div>
      </Card>
    </div>
  );
};

export default Settings;